JOGO CARREIRA FUTEBOL — BASE MUNDIAL
=====================================
Base preparada para Android/Compose.

Conteúdo:
- países/nacionalidades
- clubes de vários continentes
- competições nacionais e continentais
- carreira do jogador
- partidas, treino, mercado e temporadas
- dados separados em assets JSON para facilitar expansão futura

Fonte de dados de referência:
OpenFootball — https://github.com/openfootball/clubs
OpenFootball — https://github.com/openfootball/world
OpenFootball — https://github.com/openfootball/football.json
Os repositórios OpenFootball indicam dados públicos/CC0.

Observação:
“Completa” aqui significa uma base mundial ampla para o jogo, não todos os clubes amadores e divisões regionais existentes no planeta.
